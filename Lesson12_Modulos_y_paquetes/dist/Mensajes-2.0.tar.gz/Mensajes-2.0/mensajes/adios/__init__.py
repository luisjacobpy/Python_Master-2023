print("Cargando el subpaquete mensaje.adios") # Mensaje dentro del subpaquete

