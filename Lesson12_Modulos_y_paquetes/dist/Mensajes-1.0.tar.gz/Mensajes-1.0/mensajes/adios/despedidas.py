def despedir():
    print("Adios, me despido desde despedidas.despedir()")
    
class Despedida:
    def __init__(self):# Constructor
        print("Adiós, me despido despido desde Despedida.__init__")    