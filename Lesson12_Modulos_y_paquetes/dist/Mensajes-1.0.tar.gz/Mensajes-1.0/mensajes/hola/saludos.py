# Función saludar
def saludar():
    print("Hola te saludo desde saludos.saludar()")
    
    
class Saludo():
    def __init__(self):
        print("Hola, te saludo desde Saludos.__init__ ")
    
    
    
if __name__ == '__main__': # Almacena durante la ejecución de un programa el nombre del script
        
    saludar()