print("Cargando el subpaquete mensajes.hola...") # Mensaje dentro del subpaquete.

